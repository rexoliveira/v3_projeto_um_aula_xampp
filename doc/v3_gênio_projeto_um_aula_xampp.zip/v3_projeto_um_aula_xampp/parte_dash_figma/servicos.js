const servicos = [{
    servico: 'IPTU',
    numero:'52469',
    taxa: '137.15',
    situacao:'Pendente'
},
{
    servico: 'Repara Iluminação',
    numero:'54269',
    taxa: '0.00',
    situacao:'Andamento'
},
{
    servico: 'Reparao Calçamento',
    numero:'15268',
    taxa: '0.00',
    situacao:'Analise'
},
{
    servico: 'Recolher Entulho',
    numero:'56298',
    taxa: '17.23',
    situacao:'Pendente'
},
{
    servico: 'Crédito Estacionamento Público',
    numero:'94563',
    taxa: '50.00',
    situacao:'Efetuado'
},]