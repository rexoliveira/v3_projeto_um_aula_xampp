<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="stylesheet" href="../style/dashboard.css">

    <title>Dashboard</title>
</head>
<body>
    <header></header>
    <main>
        <h1>Crédito: <a href="https://youtu.be/nStIu7bHd9c">dpw</a></h1>
        <section class="l-cards">

            <article class="c-card">
                <section class="c-card_image">
                    <img src="https://as1.ftcdn.net/v2/jpg/01/71/25/36/1000_F_171253635_8svqUJc0BnLUtrUOP5yOMEwFwA8SZayX.jpg" width="100%" alt="image placeholder">
                </section>
                <section class="c-card_content">
                    
                    <span class="u-text-placeholder" style="width: 30%;"><h2>Nome: </h2></span>
                    
                    <span class="u-text-placeholder" style="width: 85%;"><h2>E-mail: </h2></span>
                    <span class="u-text-placeholder" style="width: 60%;"><h2>Telefone: </h2></span>
                </section>
            </article>

            <article class="c-card">
                <section class="c-card_image">
                    <img src="https://as1.ftcdn.net/v2/jpg/01/71/25/36/1000_F_171253635_8svqUJc0BnLUtrUOP5yOMEwFwA8SZayX.jpg" width="100%" alt="image placeholder">
                </section>
                <section class="c-card_content">
                    <span class="u-text-placeholder" style="width: 30%;"><h2>Nome: </h2></span>
                    <span class="u-text-placeholder" style="width: 85%;"><h2>E-mail: </h2></span>
                    <span class="u-text-placeholder" style="width: 60%;"><h2>Telefone: </h2></span>
                </section>
            </article>

            <article class="c-card">
                <section class="c-card_image">
                    <img src="https://as1.ftcdn.net/v2/jpg/01/71/25/36/1000_F_171253635_8svqUJc0BnLUtrUOP5yOMEwFwA8SZayX.jpg" width="100%" alt="image placeholder">
                </section>
                <section class="c-card_content">
                    <span class="u-text-placeholder" style="width: 30%;"><h2>Nome: </h2></span>
                    <span class="u-text-placeholder" style="width: 85%;"><h2>E-mail: </h2></span>
                    <span class="u-text-placeholder" style="width: 60%;"><h2>Telefone: </h2></span>
                </section>
            </article>

            <article class="c-card">
                <section class="c-card_image">
                    <img src="https://as1.ftcdn.net/v2/jpg/01/71/25/36/1000_F_171253635_8svqUJc0BnLUtrUOP5yOMEwFwA8SZayX.jpg" width="100%" alt="image placeholder">
                </section>
                <section class="c-card_content">
                    <span class="u-text-placeholder" style="width: 30%;"><h2>Nome: </h2></span>
                    <span class="u-text-placeholder" style="width: 85%;"><h2>E-mail: </h2></span>
                    <span class="u-text-placeholder" style="width: 60%;"><h2>Telefone: </h2></span>
                </section>
            </article>

            <article class="c-card">
                <section class="c-card_image">
                    <img src="https://as1.ftcdn.net/v2/jpg/01/71/25/36/1000_F_171253635_8svqUJc0BnLUtrUOP5yOMEwFwA8SZayX.jpg" width="100%" alt="image placeholder">
                </section>
                <section class="c-card_content">
                    <span class="u-text-placeholder" style="width: 30%;"><h2>Nome: </h2></span>
                    <span class="u-text-placeholder" style="width: 85%;"><h2>E-mail: </h2></span>
                    <span class="u-text-placeholder" style="width: 60%;"><h2>Telefone: </h2></span>
                </section>
            </article>

            <article class="c-card">
                <section class="c-card_image">
                    <img src="https://as1.ftcdn.net/v2/jpg/01/71/25/36/1000_F_171253635_8svqUJc0BnLUtrUOP5yOMEwFwA8SZayX.jpg" width="100%" alt="image placeholder">
                </section>
                <section class="c-card_content">
                    <span class="u-text-placeholder" style="width: 30%;"><h2>Nome: </h2></span>
                    <span class="u-text-placeholder" style="width: 85%;"><h2>E-mail: </h2></span>
                    <span class="u-text-placeholder" style="width: 60%;"><h2>Telefone: </h2></span>
                </section>
            </article>

        </section>
    </main>
    <footer></footer>
    
</body>
</html>