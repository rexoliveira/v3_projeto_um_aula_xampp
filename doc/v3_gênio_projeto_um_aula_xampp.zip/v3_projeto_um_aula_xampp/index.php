<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <!-- Redirecionado para página principal.html -->
    <meta http-equiv="refresh" content="0; URL='parte_dash_figma/dash_figma.html'" />
    <!--INICIAR A TELA FULL FOI DESATIVADA PARA MAIS TESTES A AJUSTES-->
    <!--Crédito tela full:http://phpbrasil.com/phorum/read.php?1,58112-->
    <!--   <script>
        function fullwin() {
            window.open("parte_dash_figma/dash_figma.php", "", "fullscreen")
        }
        </script> -->
</head>

<!-- <body onLoad="javascript:fullwin()"> -->

<body>
</body>

</html>