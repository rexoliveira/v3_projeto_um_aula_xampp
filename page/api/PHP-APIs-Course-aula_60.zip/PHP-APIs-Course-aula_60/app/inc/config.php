<?php

define('AULA', 'aula_10');

define('API_BASE_ENDPOINT', 'http://localhost/http_simple_authentication/' . AULA . '/api/');

// Joao
define('API_USER', 'FmKVnk7V71alEfW6ShmbNJyWwiNaIKwf');
define('API_PASS', 'OQoPNs3SpfXhlmUely3kX4ZMP0RrCfOz');

// // ana
// define('API_USER', '5NN43xo9KRtk1qLrcoZisqIs4NqNQj31');
// define('API_PASS', 'nPjEQz2KPg5O1714ltmo6FycwF4nRtoX');

// // carlos
// define('API_USER', 'X0uvlWxDd41CFCSPGJn3qJO2RN9q3HxX');
// define('API_PASS', 'WRB1pEfB9HbWO5Lm0WJPZVBocyifRFi9');
