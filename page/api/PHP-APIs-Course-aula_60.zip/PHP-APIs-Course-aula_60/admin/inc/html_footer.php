<?php defined('ROOT') or die('Acesso inválido'); ?>
<script src="assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>