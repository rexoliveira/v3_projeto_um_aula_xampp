<?php

define('DB_SERVER',     'localhost');
define('DB_NAME',       'loja_api');
define('DB_CHARSET',    'utf8');
define('DB_USERNAME',   'user_loja_api');
define('DB_PASSWORD',   '5ere58bA5e78yIKiguM7y5L36EN8YE');